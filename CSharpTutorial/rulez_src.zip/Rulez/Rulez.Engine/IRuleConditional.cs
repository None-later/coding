
namespace Rulez.Engine
{
	public interface IRuleConditional
	{
		bool Evaluate();
	}
}
